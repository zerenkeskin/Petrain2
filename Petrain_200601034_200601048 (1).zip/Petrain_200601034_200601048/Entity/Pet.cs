﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;

namespace petrain5webui.Entity
{
    public class Pet
    {
        [DisplayName("Fotoğraf")]
        public string Image { get; set; }
      
        public Category Category { get; set; }
        [DisplayName("İsim")]
        public string Name { get; set; }
        
        [DisplayName("Anasayfada var mı?")]
        public bool IsHome { get; set; }
      
        public int Id { get; set; }
        [DisplayName("Açıklama")]
        public string Description { get; set; }
        [DisplayName("Yaş")]

        public double Age { get; set; }
        

        public int CategoryId { get; set; }

       

    }
    
}