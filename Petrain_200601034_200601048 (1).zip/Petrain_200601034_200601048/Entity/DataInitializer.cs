﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace petrain5webui.Entity
{
    public class DataInitializer : DropCreateDatabaseIfModelChanges<DataContext>
    {
        protected override void Seed(DataContext context)
        {
            var Kategoriler = new List<Category>()
            {
                new Category(){Name ="Köpek"},
                new Category() { Name = "Kedi" },
                new Category() { Name = "Kuş" },
            };

            foreach (var kategori in Kategoriler)
            {
                context.Categories.Add(kategori);
            }
            context.SaveChanges();
            //ktegori1=köpek
            //kategori2=kedi
            //kategori3=kuş
            var Hayvanlar = new List<Pet>()
            {
                new Pet(){Name ="şemsiye", Age=2, CategoryId=2, Description="yavru kedi acil", Image = "1.jpg", IsHome=true },
                new Pet(){Name ="Mikasa", Age=3, CategoryId=2, Description="çok güzel 1 kediyim", Image = "2.jpeg",IsHome=true},
                new Pet(){Name ="Cookie", Age=2, CategoryId=1, Description="minik köpş", Image = "3.jpeg",IsHome=true},
                new Pet(){Name ="Bulut", Age=1, CategoryId=3, Description="cicikuş bulut", Image = "4.jpeg",IsHome=false},
                new Pet(){Name ="Sabri", Age=2, CategoryId=2, Description="bıldırcın sabri", Image = "5.jpeg" , IsHome=false},
                new Pet(){Name ="Remzi", Age=2, CategoryId=3, Description="şişko köpke", Image = "6.jpeg", IsHome=false},

            };
            foreach (var hayvan in Hayvanlar)
            {
                context.Pets.Add(hayvan);
            }
            context.SaveChanges();


            base.Seed(context);
        }
    }
}