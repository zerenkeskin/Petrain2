const createFooter = () => {
    let footer = document.querySelector('footer');

    footer.innerHTML = `
    
    <div class="footer-content">
        <span class="container w-100"> 2021-2022  · Petrain </span>
        <div class"row">
       <img src="~/Upload/logo.png" class="logo" alt="">
    </div>
</div>
    `;
}
createFooter();