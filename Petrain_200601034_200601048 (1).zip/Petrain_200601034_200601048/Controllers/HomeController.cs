﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using petrain5webui.Entity;
using petrain5webui.Models;

namespace petrain5webui.Controllers
{
    public class HomeController : Controller
    {
        DataContext _context = new DataContext();

        // GET: Home
        public ActionResult Index()
        {
            var hayvanlar = _context.Pets
                .Where(i => i.IsHome)
                .Select(i => new PetModel()
                {
                    Id = i.Id,
                    Name = i.Name,
                    Description = i.Description.Length > 30 ? i.Description.Substring(0, 27) + "..." : i.Description,
                    Age = i.Age,
                    Image = i.Image,
                    CategoryId = i.CategoryId
                }
                ).ToList();
            return View(hayvanlar);
        }
        public ActionResult Details(int id)
        {
            return View(_context.Pets.Where(i => i.Id == id).FirstOrDefault());
        }
        public ActionResult List()
        {
            var hayvanlar = _context.Pets

               .Select(i => new PetModel()
               {
                   Id = i.Id,
                   Name = i.Name,
                   Description = i.Description.Length > 30 ? i.Description.Substring(0, 27) + "..." : i.Description,
                   Age = i.Age,
                   Image = i.Image ?? "null.jpeg",
                   CategoryId = i.CategoryId
               }
               ).ToList();
            return View(hayvanlar);
        }

    }

}