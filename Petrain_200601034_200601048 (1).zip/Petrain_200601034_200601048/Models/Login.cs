﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace petrain5webui.Models
{
    public class Login
    {
        [DisplayName("E-Posta")]
        [EmailAddress(ErrorMessage = "E-posta formunda değil.")]
        public string Email { get; set; }

        [Required]
        [DisplayName("Şifre")]

        public string Password { get; set; }

        [DisplayName("Beni unutma")]
        public bool RememberMe { get; set; }

    }
}